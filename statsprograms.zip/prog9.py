import scipy.stats as stats 
# Scores of 10 students 
# in SMIP and DBMS courses
smip_scores = [70, 46, 94, 34, 20, 86, 18, 12, 56, 64] 
dbms_scores = [60, 66, 90, 46, 16, 98, 24, 8, 32, 54] 
# Spearman Rank Correlation 
correlation, p_value = stats.spearmanr(smip_scores, dbms_scores) 
print(f"Spearman Rank Correlation Coefficient: {correlation:.4f}") 
print(f"P-value: {p_value:.4f}")
if p_value < 0.05:
    print("There is a statistically significant correlation between SMIP and DBMS scores.")
else:
    print("There is no statistically significant correlation between SMIP and DBMS scores.")