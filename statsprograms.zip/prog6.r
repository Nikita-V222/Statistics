# Step 1: Load the data
data <- read.csv("C:/Users/Caroline Chelli/Downloads/medicalmalpractice.csv")




summary(data$Amount)             # Min, median, mean, etc.
  # Histogram

# Explore influence of factors (Specialty, Severity, etc.)


# 2. Percentages of specific specialties
# Clean the Specialty column
str(data)                 # Make sure it has rows
nrow(data)                # Should be > 0
summary(data$Specialty)   # Should not be all NA

# Step 2: Clean and create table
data$Specialty <- tolower(trimws(data$Specialty))  # Clean text
spec_table <- table(data$Specialty)                # Create table

# Step 3: Check the table again
print(spec_table)         # Now this should show frequencies

# Step 4: Calculate total
total <- sum(spec_table)

# Step 5: Define a safe function
get_percent <- function(name) {
  name <- tolower(trimws(name))
  if (name %in% names(spec_table)) {
    return(round(100 * spec_table[[name]] / total, 2))
  } else {
    return(0)
  }
}

# Step 6: Print percentages
cat("Anesthesiology: ", get_percent("anesthesiology"), "%\n")
cat("Dermatology: ", get_percent("dermatology"), "%\n")
cat("Orthopedic Surgery: ", get_percent("orthopedic surgery"), "%\n")
# 3. Relationship between Age and Amount

cor(data$Age, data$Amount, use="complete.obs")  # Correlation

hist(log10(data$Amount),
     main = "Histogram of Claim Amounts (Log Scale)",
     xlab = "Log Amount ($)",
     col = "lightblue",
     breaks = 20)

# Identify top 3 specialties
top3 <- names(sort(table(data$Specialty), decreasing = TRUE)[1:3])

# Boxplot for top 3 specialties
boxplot(Amount ~ Specialty, data = subset(data, Specialty %in% top3),
        log = "y",
        main = "Claim Amounts by Top 3 Specialties",
        xlab = "Specialty",
        ylab = "Amount ($)",
        col = "lightgreen")

