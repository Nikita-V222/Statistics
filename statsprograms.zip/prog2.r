data(mtcars)
# Select variables
x <- mtcars$wt
y <- mtcars$mpg
# Step 1: Pearson correlation test
cor_test <- cor.test(x, y, method = "pearson")
print(cor_test)
# Step 2: Q-Q plots for normality check
# Q-Q plot for x (weight)
qqnorm(x, main = "Q-Q Plot for Weight (wt)")
qqline(x, col = "red")
# Q-Q plot for y (mpg)
qqnorm(y, main = "Q-Q Plot for Miles Per Gallon (mpg)")
qqline(y, col = "red")