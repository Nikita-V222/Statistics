import pandas as pd
import statsmodels.api as sm # type: ignore
import matplotlib.pyplot as plt
from pandas.plotting import register_matplotlib_converters
register_matplotlib_converters()
df = pd.read_csv("C:/Users/Caroline Chelli/Downloads/AusAntidiabeticDrug.csv")
date = df['ds']
sales = df['y']
datetime = pd.to_datetime(date)
plt.plot(datetime, sales)
plt.xlabel("Time")
plt.ylabel("$ Millions")
plt.title("Antidiabetic Drug Sales Over Time")
plt.show()