 
# Load the data 
data <- read.csv("C:/Users/Caroline Chelli/Downloads/treatmentfacility.csv") 
# 1. Summary statistics 
summary(data) 

data$REENGINEER <- factor(data$Reengineer,
                          levels = c(0, 1),
                          labels = c("Before", "After"))
aggregate(cbind(Employee.Turnover, CI....) ~ Reengineer,
          data = data, FUN = mean)

# Step 5: Check if difference is big (T-test)
t.test(Employee.Turnover ~ Reengineer, data)
t.test(CI.... ~ Reengineer, data)

#Plot Employee Turnover 
boxplot(Employee.Turnover ~ Reengineer, data = data,
        main = "Turnover: Before vs After",
        xlab = "Reengineering",
        ylab = "Turnover (%)",
        col = c("skyblue", "peachpuff"))

#plot Confidence Interval
boxplot(CI.... ~ Reengineer, data = data,
        main = "CI: Before vs After",
        xlab = "Reengineering",
        ylab = "Behavior Problems (%)",
        col = c("lightpink", "lightgreen"))