price_data <- read.csv("C:/Users/Caroline Chelli/Downloads/pricequotes (1) (1).csv")
# View first few rows
head(price_data)
# Summary statistics function
summary_stats <- function(x) {
  n <- length(x)
  mean_val <- mean(x)
  median_val <- median(x)
  sd_val <- sd(x)
  se_mean <- sd_val / sqrt(n)
  cat("Count:", n, "\n")
  cat("Mean:", mean_val, "\n")
  cat("Median:", median_val, "\n")
  cat("Standard Deviation (SD):", sd_val, "\n")
  cat("Standard Error of the Mean (SE):", se_mean, "\n\n")
}
cat("Mary's Price Quotes Summary:\n")
summary_stats(price_data$Mary)
cat("Barry's Price Quotes Summary:\n")
summary_stats(price_data$Barry)
# Interpretation in comments:
# SD tells us how much individual quotes vary around the average quote.
# SE tells us how precisely we know the average quote estimate