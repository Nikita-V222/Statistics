data(mtcars)

# Choose two variables, for example: mpg (miles per gallon) and wt (weight)
x <- mtcars$wt
y <- mtcars$mpg

# Compute correlation
correlation <- cor(x, y)
cat("Correlation between weight and mpg:", correlation, "\n")

# Scatter plot
plot(x, y, main = "Scatter plot of Weight vs MPG",
     xlab = "Weight (1000 lbs)", ylab = "Miles Per Gallon",
     pch = 19, col = "blue")

# Add regression line
abline(lm(y ~ x), col = "red", lwd = 2)

